<?php $__env->startSection('title', 'Todo\'s List'); ?>

<?php $__env->startSection('actions'); ?>
    <button
        type="button"
        id="create-btn"
        aria-label="Go to the create page"
        title="Go to the create page"
        onclick="window.location.href='<?php echo e(route('create')); ?>';"
    >
        Create todo
    </button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div id="index-content">
        <div class="grid">
            <div class="grid-header">
                <strong>Todos</strong>
            </div>
            <?php if($todos->isNotEmpty()): ?> 
                <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <p class="<?php echo e($task->completed ? 'checked' : ''); ?>"><?php echo e($task->title); ?></p>
                    </div>
                    <div class="grid-actions">
                        <?php if(!$task->completed): ?>
                            <form action="<?php echo e(route('check', ['id' => $task->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button
                                    id="submit-btn"
                                    type="submit"
                                    class="grid-item-check"
                                    aria-label="Check task"
                                    title="Check task"
                                ></button>
                            </form>
                        <?php endif; ?>
                        <button
                            type="button"
                            class="grid-item-view"
                            aria-label="View task"
                            title="View task"
                            onclick="window.location.href='<?php echo e(route('show', ['id' => $task->id])); ?>';"
                        ></button>
                        <button
                            type="button"
                            class="grid-item-edit"
                            aria-label="Edit task"
                            title="Edit task"
                            onclick="window.location.href='<?php echo e(route('edit', ['id' => $task->id])); ?>';"
                        ></button>
                        <form action="<?php echo e(route('destroy', ['id' => $task->id])); ?>" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button
                                id="submit-btn"
                                type="submit"
                                class="grid-item-remove"
                                aria-label="Remove task"
                                title="Remove task"
                            ></button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="grid-links">
                    <?php echo e($todos->links()); ?>

                </div>
            <?php else: ?>
                <div class="grid-norecords">
                    <span>No records found.</span>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\todoapp\resources\views/todo/index.blade.php ENDPATH**/ ?>