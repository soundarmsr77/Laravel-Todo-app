<?php $__env->startSection('title', 'Show todo'); ?>

<?php $__env->startSection('back', 'true'); ?>

<?php $__env->startSection('content'); ?>

    <div id="show-content">
        <p class="name"><?php echo e($todo->title); ?></p>
        <p class="name"><?php echo e($todo->description); ?></p>
        <?php if($todo->completed): ?>
            <p class="completed-task">Completed Todo</p>
        <?php else: ?>
            <p class="pending-task">Pending Todo</p>
        <?php endif; ?>
        <div class="bottom">
            <div id="created-at-div">
                <label for="created-at">Created at</label>
                <p id="created-at"><?php echo e(date('d/m/Y', strtotime($todo->created_at))); ?></p>
            </div>
            <div id="updated-at-div">
                <label for="updated-at">Created at</label>
                <p id="updated-at"><?php echo e(date('d/m/Y', strtotime($todo->updated_at))); ?></p>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\todoapp\resources\views/todo/show.blade.php ENDPATH**/ ?>