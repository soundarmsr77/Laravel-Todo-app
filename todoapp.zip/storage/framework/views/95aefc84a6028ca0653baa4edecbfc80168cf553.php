<?php $__env->startSection('title', 'Edit todo'); ?>

<?php $__env->startSection('back', 'true'); ?>

<?php $__env->startSection('content'); ?>

    <div id="edit-content">
        <p class="name"><?php echo e($todo->title); ?></p>

        <form method="POST" action="<?php echo e(route('update', ['id' => $todo->id])); ?>" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <label for="name">Name / Description</label>
            <input
                class="input <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                id="title"
                name="title"
                type="text"
              
                maxlength="100"
                
                autofocus
                value="<?php echo e($todo->title); ?>"
            >
            <label for="description">Description *</label>
            <textarea class="form-control description"  name="description" rows="3"><?php echo e(old('description', $todo->description)); ?></textarea>
            <label class="checkbox-container">Completed
                <input
                    class="checkbox"
                    type="checkbox"
                    id="check"
                    name="check"
                    value="completed"
                    <?php echo e(($todo->completed) ? 'checked' : ''); ?>

                >
                <span class="checkmark"></span>
            </label>

            <button id="submit-btn" type="submit" aria-label="Submit form" title="Submit form">Send</button>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\todoapp\resources\views/todo/edit.blade.php ENDPATH**/ ?>